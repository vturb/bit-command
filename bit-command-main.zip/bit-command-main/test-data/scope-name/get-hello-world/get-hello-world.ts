/**
 * returns a string with the message "Hello world!".
 */

export function getHelloWorld() {
  return 'Hello world!';
}
