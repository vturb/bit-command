import React from 'react';
import { HelloWorld } from './hello-world';

export const BasicHelloWorld = () => {
  return <HelloWorld />;
};
