/**
 * this is the component's main file. to learn more, @see https://bit.dev/reference/components/component-main-file
 */
export { HelloWorldApp } from './hello-world-app.app-root';
