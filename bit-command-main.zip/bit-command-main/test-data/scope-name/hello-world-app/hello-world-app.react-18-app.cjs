const HelloWorldAppApp = {
  name: 'hello-world-app',
  entry: [require.resolve('./hello-world-app.app-root')],
};

module.exports.default = HelloWorldAppApp;
