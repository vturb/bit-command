import { HelloWorldApp } from './hello-world-app.app-root';

export const HelloWorldAppBasic = () => {
  return <HelloWorldApp />;
};
