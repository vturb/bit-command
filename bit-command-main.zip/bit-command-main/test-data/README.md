## bit.dev

  Start bit.bit:
  ```js
  bit run bit-dev
  ```
  